# 3D-Taj-Mahal-Model
3D model of Taj Mahal in Opengl.
