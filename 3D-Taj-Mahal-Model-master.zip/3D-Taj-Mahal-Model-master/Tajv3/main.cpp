//
//  main.cpp
//  Taj
//
//  Created by keshav goyal on 07/04/18.
//  Copyright © 2018 keshav goyal. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
